CREATE TABLE `login_save` (
  `id` int() PRIMARY KEY NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `login_save`
CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT;
