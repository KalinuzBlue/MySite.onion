import sys
input=sys.argv[1]
print(input)
