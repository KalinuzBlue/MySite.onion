<?php
$text = "Text you want to add to your file";
file_put_contents('template.html', $text, FILE_APPEND | LOCK_EX);
?>

