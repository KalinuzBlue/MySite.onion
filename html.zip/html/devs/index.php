<?php     $images = glob('/imgs/*.{jpg,png}');          foreach($images as $image) {         echo $value;     } ?>
