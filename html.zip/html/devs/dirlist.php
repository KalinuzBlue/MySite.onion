$all = glob('/path/to/dir/*.*');

